import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, User, LogOut, Wallet, PiggyBank, Eye, EyeOff, 
  ShieldCheck, ChevronRight, Menu, X, CreditCard, 
  TrendingUp, Bell, Settings, HelpCircle, ArrowUpRight, 
  ArrowDownLeft, Search, Globe, Bot, FileText,
  Shield, Sliders, Calendar, Zap, CreditCard as CardIcon,
  CheckCircle2, AlertCircle
} from 'lucide-react';
import Papa from 'papaparse';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { USER_CREDENTIALS, SPREADSHEET_CSV_URL } from './constants';
import { UserAccount, Transaction, InvestmentDetail, Notification } from './types';
import { ChatAgent } from './components/ChatAgent';
import { Plus, Minus, Info } from 'lucide-react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [accountData, setAccountData] = useState<UserAccount | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      title: 'Mise à jour du site',
      message: 'Le bouton "Paramètres" a été supprimé de la barre latérale pour simplifier l\'interface.',
      date: 'Aujourd\'hui',
      type: 'removed',
      isRead: false
    },
    {
      id: '2',
      title: 'Nouvelle fonctionnalité',
      message: 'Le système de notifications par cloche est désormais actif !',
      date: 'Aujourd\'hui',
      type: 'added',
      isRead: false
    },
    {
      id: '3',
      title: 'Mise à jour du site',
      message: 'Le bouton "RIB" a été supprimé de l\'interface principale.',
      date: 'Aujourd\'hui',
      type: 'removed',
      isRead: false
    },
    {
      id: '4',
      title: 'Mise à jour du site',
      message: 'Le bloc de performance flottant a été retiré de la page d\'accueil.',
      date: 'Aujourd\'hui',
      type: 'removed',
      isRead: false
    },
    {
      id: '5',
      title: 'Mise à jour du site',
      message: 'Les boutons de navigation (Particuliers, Professionnels, etc.) ont été supprimés.',
      date: 'Aujourd\'hui',
      type: 'removed',
      isRead: false
    },
    {
      id: '6',
      title: 'Mise à jour du site',
      message: 'Les blocs d\'information (Prélèvement, Épargne, Sécurité, Alertes) ont été retirés.',
      date: 'Aujourd\'hui',
      type: 'removed',
      isRead: false
    },
    {
      id: '7',
      title: 'Mise à jour du site',
      message: 'Les boutons d\'action (Relevés, Plafonds, Opposition) ont été supprimés.',
      date: 'Aujourd\'hui',
      type: 'removed',
      isRead: false
    },
    {
      id: '9',
      title: 'Mise à jour majeure',
      message: 'Simplification totale de l\'accueil : Suppression de la navigation, du pied de page et des sections d\'information. Ajout d\'un formulaire de connexion direct avec arrière-plan flouté.',
      date: 'Aujourd\'hui',
      type: 'update',
      isRead: false
    },
    {
      id: '10',
      title: 'Nouveau service',
      message: 'Vous pouvez désormais effectuer une demande de prêt directement depuis votre tableau de bord.',
      date: 'Aujourd\'hui',
      type: 'update',
      isRead: false
    }
  ]);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };
  const [theme, setTheme] = useState<'white-black' | 'black-white' | 'blue-black' | 'white-red'>('white-black');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const validPassword = USER_CREDENTIALS[username];
    
    if (validPassword && validPassword === password) {
      setIsLoggedIn(true);
      setShowLoginModal(false);
      fetchAccountData(username);
    } else {
      setError('Identifiants incorrects. Veuillez réessayer.');
    }
  };

  const fetchAccountData = (name: string) => {
    setLoading(true);
    Papa.parse(SPREADSHEET_CSV_URL, {
      download: true,
      header: false,
      skipEmptyLines: true,
      complete: (results) => {
        const rows = results.data as string[][];
        
        let headerRowIndex = -1;
        for (let i = 0; i < rows.length; i++) {
          if (rows[i].some(cell => {
            const c = cell?.toString().toLowerCase();
            return c.includes('nom') || c.includes('solde') || c.includes('livret a') || c.includes('investissement');
          })) {
            headerRowIndex = i;
            break;
          }
        }

        if (headerRowIndex !== -1) {
          const headers = rows[headerRowIndex];
          const dataRows = rows.slice(headerRowIndex + 1);
          
          const nomIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('nom'));
          const soldeIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('solde'));
          const livretAIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('livret a'));
          const investIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('investissement'));
          const entrepriseIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('compte entreprise'));

          const userRow = dataRows.find(row => {
            const rowName = (row[nomIdx] || '').toString().trim().toLowerCase();
            return rowName === name.toLowerCase();
          });

          if (userRow) {
            const cleanValue = (val: string) => {
              if (!val) return '0.00';
              return val.toString().replace(/[€$£\u00A0]/g, '').trim() || '0.00';
            };

            const transactions: Transaction[] = [];
            const investBreakdown: InvestmentDetail[] = [];
            const breakdownKeywords = ['pea', 'crypto', 'assurance vie', 'bourse', 'titres', 'immobilier'];
            
            headers.forEach((h, idx) => {
              const header = h?.toString().toLowerCase() || '';
              if (breakdownKeywords.some(k => header.includes(k))) {
                const val = userRow[idx];
                if (val && val !== '0' && val !== '0.00') {
                  investBreakdown.push({
                    label: h.toString(),
                    amount: cleanValue(val)
                  });
                }
              }
            });

            const perfIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('performance') || h?.toString().toLowerCase().includes('évolution'));
            const performance = perfIdx !== -1 ? userRow[perfIdx] : null;

            // Assume K, L, M, N are columns 9, 10, 11, 12 relative to B (index 0)
            // But let's check if we can find headers for them
            const dateIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('date'));
            const descIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('libellé') || h?.toString().toLowerCase().includes('description'));
            const transAmountIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('montant op') || h?.toString().toLowerCase().includes('valeur'));
            const typeIdx = headers.findIndex(h => h?.toString().toLowerCase().includes('type') || h?.toString().toLowerCase().includes('catégorie'));

            // Fallback to indices if headers not found
            const finalDateIdx = dateIdx !== -1 ? dateIdx : 9;
            const finalDescIdx = descIdx !== -1 ? descIdx : 10;
            const finalTransAmountIdx = transAmountIdx !== -1 ? transAmountIdx : 11;
            const finalTypeIdx = typeIdx !== -1 ? typeIdx : 12;

            if (userRow[finalDateIdx] && userRow[finalDescIdx]) {
              const amountStr = userRow[finalTransAmountIdx] || '0';
              const isNegative = amountStr.includes('-') || (userRow[finalTypeIdx] || '').toLowerCase().includes('débit');
              
              transactions.push({
                date: userRow[finalDateIdx],
                description: userRow[finalDescIdx],
                amount: cleanValue(amountStr),
                type: isNegative ? 'down' : 'up'
              });
            }

            const entrepriseVal = entrepriseIdx !== -1 ? userRow[entrepriseIdx] : null;
            const hasEntreprise = entrepriseVal && entrepriseVal.toString().trim() !== "" && entrepriseVal.toString().trim() !== "0" && entrepriseVal.toString().trim() !== "0.00";

            setAccountData({
              name: userRow[nomIdx] || name,
              solde: cleanValue(userRow[soldeIdx]),
              livretA: cleanValue(userRow[livretAIdx]),
              investissements: cleanValue(userRow[investIdx]),
              compteEntreprise: hasEntreprise ? cleanValue(entrepriseVal) : null,
              performance: performance,
              investBreakdown: investBreakdown,
              transactions: transactions
            });
          } else {
            setAccountData({
              name: name,
              solde: "0.00",
              livretA: "0.00",
              investissements: "0.00",
              compteEntreprise: null,
              performance: null,
              investBreakdown: [],
              transactions: []
            });
          }
        } else {
          setError('Structure du tableur non reconnue. Vérifiez les en-têtes.');
        }
        setLoading(false);
      },
      error: (err) => {
        console.error('Error fetching data:', err);
        setError('Impossible de récupérer vos données. Vérifiez que le tableur est public.');
        setLoading(false);
      }
    });
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isLoggedIn && username) {
      interval = setInterval(() => {
        fetchAccountData(username);
      }, 60000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLoggedIn, username]);

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setPassword('');
    setAccountData(null);
    setActiveTab('dashboard');
  };

  // Landing Page Component
  const LandingPage = () => (
    <div className="min-h-screen relative flex items-center justify-center overflow-hidden font-sans">
      {/* Background Image with Blur */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=2069&auto=format&fit=crop" 
          alt="Background" 
          className="w-full h-full object-cover blur-md scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Login Form Container */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-md bg-white/90 backdrop-blur-xl rounded-[2.5rem] shadow-2xl p-10 overflow-hidden mx-4"
      >
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center mb-6 shadow-xl shadow-black/20">
            <ShieldCheck className="text-white w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight">MAZE BANK</h2>
          <p className="text-gray-500 text-sm mt-1 text-center">Identifiez-vous pour accéder à vos comptes</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1">Utilisateur</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Votre nom"
                className="w-full bg-gray-50 border-2 border-transparent rounded-2xl py-4 pl-12 pr-4 focus:border-black/5 focus:bg-white transition-all outline-none text-gray-900"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1">Mot de passe</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-gray-50 border-2 border-transparent rounded-2xl py-4 pl-12 pr-12 focus:border-black/5 focus:bg-white transition-all outline-none text-gray-900 font-mono"
                required
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {error && (
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 text-sm text-center bg-red-50 py-3 rounded-2xl font-medium"
            >
              {error}
            </motion.p>
          )}

          <button 
            type="submit"
            className="w-full bg-black text-white rounded-2xl py-4 font-bold hover:bg-gray-800 transition-all shadow-xl shadow-black/10 flex items-center justify-center group"
          >
            Se connecter
            <ChevronRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>
      </motion.div>
    </div>
  );

  // Business Account View Component
  const BusinessAccountView = () => {
    return (
      <div className="flex-1 flex items-center justify-center py-12">
        <motion.div 
          initial={{ opacity: 0, scale: 0.98, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className={cn(
            "w-full max-w-6xl p-20 rounded-[4rem] shadow-2xl relative overflow-hidden",
            theme === 'black-white' ? "bg-zinc-900 border-zinc-800" : 
            theme === 'blue-black' ? "bg-blue-900 border-blue-800" :
            theme === 'white-red' ? "bg-red-600 border-red-500" :
            "bg-white border-gray-100 shadow-black/5"
          )}
        >
          {/* Background Globe Icon - Massive and subtle */}
          <div className={cn(
            "absolute -right-20 -bottom-20 pointer-events-none",
            theme === 'white-red' ? "opacity-[0.1]" : "opacity-[0.03]"
          )}>
            <Globe className={cn(
              "w-[45rem] h-[45rem]",
              (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white" : "text-black"
            )} />
          </div>

          <div className="relative z-10">
            <div className="flex items-center space-x-4 mb-16">
              <div className={cn(
                "w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl",
                theme === 'white-red' ? "bg-white/20" : "bg-black shadow-black/20"
              )}>
                <Globe className="text-white w-7 h-7" />
              </div>
              <div>
                <h2 className={cn(
                  "text-2xl font-bold",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white" : "text-gray-900"
                )}>Compte Entreprise</h2>
                <p className={cn(
                  "text-xs font-bold uppercase tracking-[0.2em]",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/40" : "text-gray-400"
                )}>Maze Bank Professional</p>
              </div>
            </div>
            
            <div className="mb-28">
              <p className={cn(
                "text-sm font-bold uppercase tracking-[0.3em] mb-8",
                (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/40" : "text-gray-400"
              )}>Solde Total Disponible</p>
              <div className="flex items-baseline space-x-6">
                <span className={cn(
                  "text-[13rem] font-bold tracking-tighter leading-none",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white" : "text-gray-900"
                )}>
                  {accountData?.compteEntreprise || "0"}
                </span>
                <span className={cn(
                  "text-7xl font-bold",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/20" : "text-gray-200"
                )}>€</span>
              </div>
            </div>
            
            <div className={cn(
              "grid grid-cols-1 md:grid-cols-2 gap-24 pt-16 border-t",
              (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "border-white/10" : "border-gray-100"
            )}>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className={cn(
                    "w-2.5 h-2.5 rounded-full shadow-sm",
                    theme === 'white-red' ? "bg-white shadow-white/50" : "bg-blue-500 shadow-blue-500/50"
                  )} />
                  <p className={cn(
                    "text-sm font-bold uppercase tracking-[0.2em]",
                    (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/40" : "text-gray-400"
                  )}>Encours CB Pro</p>
                </div>
                <p className={cn(
                  "text-5xl font-bold",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white" : "text-gray-900"
                )}>0.00 €</p>
                <p className={cn(
                  "text-xs",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/40" : "text-gray-400"
                )}>Prochain prélèvement le 31/03</p>
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className={cn(
                    "w-2.5 h-2.5 rounded-full shadow-sm",
                    theme === 'white-red' ? "bg-white shadow-white/50" : "bg-green-500 shadow-green-500/50"
                  )} />
                  <p className={cn(
                    "text-sm font-bold uppercase tracking-[0.2em]",
                    (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/40" : "text-gray-400"
                  )}>Autorisation découvert</p>
                </div>
                <p className={cn(
                  "text-5xl font-bold",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white" : "text-gray-900"
                )}>5,000.00 €</p>
                <p className={cn(
                  "text-xs",
                  (theme === 'black-white' || theme === 'blue-black' || theme === 'white-red') ? "text-white/40" : "text-gray-400"
                )}>Taux débiteur : 8.50%</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  };

  const SettingsView = () => (
    <div className="space-y-12 max-w-4xl">
      <div className="flex flex-col space-y-2">
        <h2 className={cn(
          "text-4xl font-bold tracking-tight",
          (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
        )}>Paramètres</h2>
        <p className={cn(
          "text-lg",
          (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-400" : "text-gray-500"
        )}>Personnalisez votre expérience bancaire MAZE BANK</p>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <div className={cn(
          "p-10 rounded-[3rem] border transition-all",
          (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-100 shadow-sm"
        )}>
          <div className="flex items-center space-x-4 mb-8">
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center",
              (theme === 'black-white' || theme === 'blue-black') ? "bg-white/10" : "bg-black/5"
            )}>
              <Globe className={cn(
                "w-6 h-6",
                (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-black"
              )} />
            </div>
            <h3 className={cn(
              "text-xl font-bold",
              (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
            )}>Thème visuel</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { id: 'white-black', name: 'Blanc et Noir', colors: ['bg-white', 'bg-black'], desc: 'Classique et épuré' },
              { id: 'black-white', name: 'Noir et Blanc', colors: ['bg-black', 'bg-white'], desc: 'Mode sombre élégant' },
              { id: 'blue-black', name: 'Bleu et Noir', colors: ['bg-blue-900', 'bg-black'], desc: 'Profondeur nocturne' },
              { id: 'white-red', name: 'Blanc et Rouge', colors: ['bg-white', 'bg-red-600'], desc: 'Énergie et passion' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id as any)}
                className={cn(
                  "p-6 rounded-[2rem] border-2 transition-all flex flex-col items-center text-center space-y-4 group",
                  theme === t.id 
                    ? (theme === 'black-white' || theme === 'blue-black' ? "border-white bg-white/5" : "border-black bg-gray-50")
                    : (theme === 'black-white' || theme === 'blue-black' ? "border-transparent hover:border-zinc-700 bg-zinc-800/50" : "border-transparent hover:border-gray-200 bg-gray-50/50")
                )}
              >
                <div className="flex -space-x-2">
                  <div className={cn("w-10 h-10 rounded-full border-2 border-white shadow-sm", t.colors[0])} />
                  <div className={cn("w-10 h-10 rounded-full border-2 border-white shadow-sm", t.colors[1])} />
                </div>
                <div>
                  <p className={cn(
                    "font-bold text-sm mb-1",
                    (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                  )}>{t.name}</p>
                  <p className={cn(
                    "text-[10px] uppercase tracking-widest font-medium opacity-50",
                    (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                  )}>{t.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  // Dashboard Component
  const Dashboard = () => (
    <div className={cn(
      "min-h-screen flex font-sans transition-colors duration-300",
      theme === 'black-white' ? "bg-black" : 
      theme === 'blue-black' ? "bg-black" : 
      "bg-[#F8F9FA]"
    )}>
      {/* Desktop Sidebar */}
      <aside className={cn(
        "hidden lg:flex w-72 border-r flex-col sticky top-0 h-screen transition-colors duration-300",
        theme === 'black-white' ? "bg-zinc-900 border-zinc-800" : 
        theme === 'blue-black' ? "bg-blue-950 border-blue-900" : 
        "bg-white border-gray-100"
      )}>
        <div className="p-8">
          <div className="flex items-center space-x-3 mb-12">
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center shadow-lg",
              theme === 'white-red' ? "bg-red-600 shadow-red-600/20" : "bg-black shadow-black/20"
            )}>
              <ShieldCheck className="text-white w-6 h-6" />
            </div>
            <span className={cn(
              "font-bold text-xl tracking-tight",
              (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
            )}>MAZE BANK</span>
          </div>

          <nav className="space-y-2">
            {[
              { id: 'dashboard', icon: Wallet, label: 'Tableau de bord' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={cn(
                  "w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all font-medium group",
                  activeTab === item.id 
                    ? (theme === 'white-red' ? "bg-red-600 text-white shadow-lg shadow-red-600/20" : "bg-black text-white shadow-lg shadow-black/10")
                    : (theme === 'black-white' || theme === 'blue-black' ? "text-zinc-400 hover:bg-white/5 hover:text-white" : "text-gray-500 hover:bg-gray-50 hover:text-black")
                )}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            ))}
            
            {accountData?.compteEntreprise && (
              <button
                onClick={() => setActiveTab('business')}
                className={cn(
                  "w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all font-medium group",
                  activeTab === 'business' 
                    ? (theme === 'white-red' ? "bg-red-600 text-white shadow-lg shadow-red-600/20" : "bg-black text-white shadow-lg shadow-black/10")
                    : (theme === 'black-white' || theme === 'blue-black' ? "text-zinc-400 hover:bg-white/5 hover:text-white" : "text-gray-500 hover:bg-gray-50 hover:text-black")
                )}
              >
                <Globe className="w-5 h-5" />
                <span>Compte Entreprise</span>
              </button>
            )}

          </nav>
        </div>

        <div className="mt-auto p-8">
          <div className={cn(
            "rounded-2xl p-4 mb-6 transition-colors duration-300",
            theme === 'black-white' ? "bg-zinc-800" : 
            theme === 'blue-black' ? "bg-blue-900" : 
            "bg-gray-50"
          )}>
            <div className="flex items-center space-x-3 mb-3">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center",
                (theme === 'black-white' || theme === 'blue-black') ? "bg-white/10" : "bg-black/5"
              )}>
                <HelpCircle className={cn(
                  "w-4 h-4",
                  (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-500"
                )} />
              </div>
              <span className={cn(
                "text-xs font-bold",
                (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
              )}>Besoin d'aide ?</span>
            </div>
            <p className={cn(
              "text-[10px] leading-relaxed mb-4",
              (theme === 'black-white' || theme === 'blue-black') ? "text-white/60" : "text-gray-400"
            )}>Votre conseiller est disponible du lundi au vendredi de 9h à 18h.</p>
            <button 
              onClick={() => setIsChatOpen(true)}
              className={cn(
                "w-full py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all flex items-center justify-center space-x-2",
                theme === 'white-red' ? "bg-red-600 text-white hover:bg-red-700" : "bg-black text-white hover:bg-gray-800"
              )}
            >
              <Bot className="w-3 h-3" />
              <span>Parler à l'IA</span>
            </button>
          </div>
          
          <button 
            onClick={handleLogout}
            className={cn(
              "w-full flex items-center justify-between px-4 py-3 rounded-2xl transition-all font-medium",
              (theme === 'black-white' || theme === 'blue-black') ? "text-red-400 hover:bg-red-900/20" : "text-red-500 hover:bg-red-50"
            )}
          >
            <span className="flex items-center space-x-3">
              <LogOut className="w-5 h-5" />
              <span>Déconnexion</span>
            </span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className={cn(
          "backdrop-blur-md border-b px-6 lg:px-10 py-4 sticky top-0 z-40 transition-colors duration-300",
          theme === 'black-white' ? "bg-zinc-900/80 border-zinc-800" : 
          theme === 'blue-black' ? "bg-blue-950/80 border-blue-900" : 
          "bg-white/80 border-gray-100"
        )}>
          <div className="flex items-center justify-between">
            <div className="flex items-center lg:hidden">
              <div className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center mr-3",
                theme === 'white-red' ? "bg-red-600" : "bg-black"
              )}>
                <ShieldCheck className="text-white w-5 h-5" />
              </div>
              <span className={cn(
                "font-bold text-lg",
                (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
              )}>MAZE BANK</span>
            </div>

            <div className={cn(
              "hidden md:flex items-center px-4 py-2 rounded-xl w-96 transition-colors duration-300",
              (theme === 'black-white' || theme === 'blue-black') ? "bg-white/5" : "bg-gray-50"
            )}>
              <Search className={cn(
                "w-4 h-4 mr-2",
                (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
              )} />
              <input 
                type="text" 
                placeholder="Rechercher une opération..." 
                className={cn(
                  "bg-transparent border-none outline-none text-sm w-full",
                  (theme === 'black-white' || theme === 'blue-black') ? "text-white placeholder:text-zinc-600" : "text-gray-900 placeholder:text-gray-400"
                )}
              />
            </div>

            <div className="flex items-center space-x-4 relative">
              <button 
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  if (!showNotifications) markAllAsRead();
                }}
                className={cn(
                  "p-2 rounded-xl transition-all relative",
                  (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-400 hover:text-white hover:bg-white/5" : "text-gray-400 hover:text-black hover:bg-gray-50",
                  showNotifications && ((theme === 'black-white' || theme === 'blue-black') ? "text-white bg-white/5" : "text-black bg-gray-50")
                )}
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
                )}
              </button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className={cn(
                      "absolute top-full right-0 mt-2 w-80 rounded-2xl shadow-2xl z-50 overflow-hidden border",
                      (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-100"
                    )}
                  >
                    <div className={cn(
                      "p-4 border-b flex items-center justify-between",
                      (theme === 'black-white' || theme === 'blue-black') ? "border-zinc-800" : "border-gray-100"
                    )}>
                      <h3 className={cn(
                        "font-bold",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                      )}>Notifications</h3>
                      <span className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">
                        {notifications.length} Messages
                      </span>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length > 0 ? (
                        notifications.map((notification) => (
                          <div 
                            key={notification.id}
                            className={cn(
                              "p-4 border-b last:border-0 transition-colors",
                              (theme === 'black-white' || theme === 'blue-black') ? "border-zinc-800 hover:bg-white/5" : "border-gray-100 hover:bg-gray-50"
                            )}
                          >
                            <div className="flex items-start space-x-3">
                              <div className={cn(
                                "p-2 rounded-lg mt-0.5",
                                notification.type === 'added' ? "bg-green-500/10 text-green-500" :
                                notification.type === 'removed' ? "bg-red-500/10 text-red-500" :
                                "bg-blue-500/10 text-blue-500"
                              )}>
                                {notification.type === 'added' ? <Plus className="w-4 h-4" /> :
                                 notification.type === 'removed' ? <Minus className="w-4 h-4" /> :
                                 <Info className="w-4 h-4" />}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className={cn(
                                  "text-sm font-bold mb-1",
                                  (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                                )}>{notification.title}</p>
                                <p className={cn(
                                  "text-xs leading-relaxed mb-2",
                                  (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-400" : "text-gray-500"
                                )}>{notification.message}</p>
                                <span className="text-[10px] text-zinc-500 font-medium uppercase tracking-wider">
                                  {notification.date}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="p-8 text-center">
                          <p className="text-sm text-zinc-500">Aucune notification</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              <div className={cn(
                "h-8 w-px",
                (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-800" : "bg-gray-100"
              )} />
              <div className="flex items-center space-x-3 pl-2">
                <div className="text-right hidden sm:block">
                  <p className={cn(
                    "text-sm font-bold",
                    (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                  )}>{accountData?.name}</p>
                  <p className={cn(
                    "text-[10px] font-bold uppercase tracking-widest",
                    (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                  )}>Client Premium</p>
                </div>
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center font-bold",
                  theme === 'white-red' ? "bg-red-600 text-white" : "bg-black text-white"
                )}>
                  {accountData?.name?.[0]}
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className={cn(
          "p-6 lg:p-10 w-full flex-1 flex flex-col",
          activeTab === 'business' ? "max-w-none" : "max-w-7xl mx-auto space-y-10"
        )}>
          {activeTab === 'business' ? (
            <BusinessAccountView />
          ) : (
            <>
              {/* Welcome Header */}
              <section className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <h1 className={cn(
                    "text-4xl font-bold tracking-tight",
                    (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                  )}>
                    Bonjour, {accountData?.name}
                  </h1>
                  <p className={cn(
                    "mt-2 flex items-center",
                    (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-500"
                  )}>
                    <Globe className="w-4 h-4 mr-2" />
                    Dernière connexion : Aujourd'hui à {new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button className={cn(
                    "px-5 py-2.5 border rounded-xl text-sm font-bold transition-all flex items-center",
                    (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800 text-white hover:bg-zinc-800" : "bg-white border-gray-200 text-gray-900 hover:bg-gray-50"
                  )}>
                    <ArrowUpRight className="w-4 h-4 mr-2" />
                    Virement
                  </button>
                  <a 
                    href="https://docs.google.com/forms/d/e/1FAIpQLSd_dQq1vFKehGBMdXj479AnrF9_jENHzJkA7dqYAls6oD5nWw/viewform?usp=header"
                    target="_blank"
                    rel="noopener noreferrer"
                    className={cn(
                      "px-5 py-2.5 border rounded-xl text-sm font-bold transition-all flex items-center",
                      (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800 text-white hover:bg-zinc-800" : "bg-white border-gray-200 text-gray-900 hover:bg-gray-50"
                    )}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Demande de prêt
                  </a>
                </div>
              </section>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Main Balance */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "p-8 rounded-3xl shadow-sm border relative overflow-hidden group min-h-[280px] flex flex-col justify-between transition-colors duration-300",
                    (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-100"
                  )}
                >
                  <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity">
                    <Wallet className={cn(
                      "w-32 h-32",
                      (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-black"
                    )} />
                  </div>
                  <div className="relative z-10 h-full flex flex-col">
                    <div className="flex items-center justify-between mb-8">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center shadow-xl",
                        theme === 'white-red' ? "bg-red-600 shadow-red-600/20" : "bg-black shadow-black/20"
                      )}>
                        <Wallet className="text-white w-6 h-6" />
                      </div>
                      <span className={cn(
                        "px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] rounded-full",
                        (theme === 'black-white' || theme === 'blue-black') ? "bg-green-500/20 text-green-400" : "bg-green-50 text-green-600"
                      )}>Actif</span>
                    </div>
                    <div>
                      <p className={cn(
                        "text-[10px] font-bold uppercase tracking-[0.25em] mb-2",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                      )}>Compte Courant</p>
                      {loading ? (
                        <div className={cn(
                          "h-12 w-48 animate-pulse rounded-xl",
                          (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-800" : "bg-gray-100"
                        )} />
                      ) : (
                        <div className="flex items-baseline space-x-2">
                          <span className={cn(
                            "text-5xl font-bold tracking-tighter leading-none",
                            (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                          )}>
                            {accountData?.solde?.split('.')[0] || "0"}
                          </span>
                          <span className={cn(
                            "text-2xl font-bold",
                            (theme === 'black-white' || theme === 'blue-black') ? "text-white/20" : "text-gray-200"
                          )}>€</span>
                        </div>
                      )}
                    </div>
                    <div className={cn(
                      "mt-auto pt-6 border-t flex items-center justify-between",
                      (theme === 'black-white' || theme === 'blue-black') ? "border-zinc-800" : "border-gray-50"
                    )}>
                      <p className={cn(
                        "text-xs font-medium",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                      )}>Disponible immédiatement</p>
                      <ChevronRight className={cn(
                        "w-4 h-4",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-700" : "text-gray-200"
                      )} />
                    </div>
                  </div>
                </motion.div>

                {/* Livret A */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className={cn(
                    "p-8 rounded-3xl shadow-sm border relative overflow-hidden group min-h-[280px] flex flex-col justify-between transition-colors duration-300",
                    (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-100"
                  )}
                >
                  <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity">
                    <PiggyBank className={cn(
                      "w-32 h-32",
                      (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-black"
                    )} />
                  </div>
                  <div className="relative z-10 h-full flex flex-col">
                    <div className="flex items-center justify-between mb-8">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center shadow-xl",
                        theme === 'white-red' ? "bg-red-600 shadow-red-600/20" : "bg-black shadow-black/20"
                      )}>
                        <PiggyBank className="text-white w-6 h-6" />
                      </div>
                      <span className={cn(
                        "px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] rounded-full",
                        (theme === 'black-white' || theme === 'blue-black') ? "bg-blue-500/20 text-blue-400" : "bg-blue-50 text-blue-600"
                      )}>1.00%</span>
                    </div>
                    <div>
                      <p className={cn(
                        "text-[10px] font-bold uppercase tracking-[0.25em] mb-2",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                      )}>Livret A</p>
                      {loading ? (
                        <div className={cn(
                          "h-12 w-48 animate-pulse rounded-xl",
                          (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-800" : "bg-gray-100"
                        )} />
                      ) : (
                        <div className="flex items-baseline space-x-2">
                          <span className={cn(
                            "text-5xl font-bold tracking-tighter leading-none",
                            (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                          )}>
                            {accountData?.livretA?.split('.')[0] || "0"}
                          </span>
                          <span className={cn(
                            "text-2xl font-bold",
                            (theme === 'black-white' || theme === 'blue-black') ? "text-white/20" : "text-gray-200"
                          )}>€</span>
                        </div>
                      )}
                    </div>
                    <div className={cn(
                      "mt-auto pt-6 border-t flex items-center justify-between",
                      (theme === 'black-white' || theme === 'blue-black') ? "border-zinc-800" : "border-gray-50"
                    )}>
                      <p className={cn(
                        "text-xs font-medium",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                      )}>Épargne sécurisée</p>
                      <ChevronRight className={cn(
                        "w-4 h-4",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-700" : "text-gray-200"
                      )} />
                    </div>
                  </div>
                </motion.div>

                {/* Investment Card */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className={cn(
                    "p-8 rounded-3xl shadow-sm border relative overflow-hidden group min-h-[280px] flex flex-col justify-between transition-colors duration-300",
                    (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-900 border-zinc-800" : "bg-white border-gray-100"
                  )}
                >
                  <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity">
                    <TrendingUp className={cn(
                      "w-32 h-32",
                      (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-black"
                    )} />
                  </div>
                  <div className="relative z-10 h-full flex flex-col">
                    <div className="flex items-center justify-between mb-8">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center shadow-xl",
                        theme === 'white-red' ? "bg-red-600 shadow-red-600/20" : "bg-black shadow-black/20"
                      )}>
                        <TrendingUp className="text-white w-6 h-6" />
                      </div>
                      <span className={cn(
                        "px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] rounded-full",
                        (theme === 'black-white' || theme === 'blue-black') ? "bg-purple-500/20 text-purple-400" : "bg-purple-50 text-purple-600"
                      )}>Bourse</span>
                    </div>
                    <div>
                      <p className={cn(
                        "text-[10px] font-bold uppercase tracking-[0.25em] mb-2",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                      )}>Portefeuille Titres</p>
                      {loading ? (
                        <div className={cn(
                          "h-12 w-48 animate-pulse rounded-xl",
                          (theme === 'black-white' || theme === 'blue-black') ? "bg-zinc-800" : "bg-gray-100"
                        )} />
                      ) : (
                        <div className="flex items-baseline space-x-2">
                          <span className={cn(
                            "text-5xl font-bold tracking-tighter leading-none",
                            (theme === 'black-white' || theme === 'blue-black') ? "text-white" : "text-gray-900"
                          )}>
                            {accountData?.investissements?.split('.')[0] || "0"}
                          </span>
                          <span className={cn(
                            "text-2xl font-bold",
                            (theme === 'black-white' || theme === 'blue-black') ? "text-white/20" : "text-gray-200"
                          )}>€</span>
                        </div>
                      )}
                    </div>
                    <div className={cn(
                      "mt-auto pt-6 border-t flex items-center justify-between",
                      (theme === 'black-white' || theme === 'blue-black') ? "border-zinc-800" : "border-gray-50"
                    )}>
                      <p className={cn(
                        "text-xs font-medium",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-500" : "text-gray-400"
                      )}>Performance : {accountData?.performance || '+0.0%'} ce mois</p>
                      <ChevronRight className={cn(
                        "w-4 h-4",
                        (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-700" : "text-gray-200"
                      )} />
                    </div>
                  </div>
                </motion.div>
              </div>
            </>
          )}
        </main>

        <footer className={cn(
          "p-10 text-center border-t mt-auto",
          (theme === 'black-white' || theme === 'blue-black') ? "border-zinc-800" : "border-gray-100"
        )}>
          <p className={cn(
            "text-[10px] font-bold uppercase tracking-[0.3em]",
            (theme === 'black-white' || theme === 'blue-black') ? "text-zinc-600" : "text-gray-400"
          )}>
            MAZE BANK Internationale • Sécurité Certifiée ISO 27001
          </p>
        </footer>
      </div>
    </div>
  );

  return (
    <>
      {isLoggedIn ? <Dashboard /> : <LandingPage />}
      <ChatAgent 
        isOpen={isChatOpen} 
        onClose={() => setIsChatOpen(false)} 
        userName={accountData?.name} 
      />
    </>
  );
}
