import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Bot, User, Loader2, Minimize2, Maximize2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface Message {
  role: 'user' | 'model';
  content: string;
}

interface ChatAgentProps {
  isOpen: boolean;
  onClose: () => void;
  userName?: string;
}

export const ChatAgent: React.FC<ChatAgentProps> = ({ isOpen, onClose, userName }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', content: `Bonjour ${userName || ''} ! Je suis l'assistant virtuel de MAZE BANK. Comment puis-je vous aider aujourd'hui ?` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const model = "gemini-3-flash-preview";
      
      const chat = ai.chats.create({
        model: model,
        config: {
          systemInstruction: `Tu es l'assistant virtuel de MAZE BANK, une banque privée de prestige. 
          Ton ton est professionnel, courtois et rassurant. 
          Tu aides les clients avec des questions générales sur leurs comptes, l'épargne, les investissements et la sécurité.
          Ne donne jamais de conseils financiers spécifiques ou de promesses de rendement.
          Si on te demande des informations confidentielles, rappelle que tu es un agent IA et que pour des opérations sensibles, ils doivent contacter leur conseiller dédié.
          Réponds toujours en français.`,
        },
      });

      // Prepare history for the chat
      // Note: sendMessage only takes the message string, but we can use history if needed.
      // For simplicity in this implementation, we'll just send the current message.
      // In a more advanced version, we'd pass the full history.
      
      const response = await chat.sendMessage({ message: userMessage });
      const aiResponse = response.text || "Désolé, je n'ai pas pu traiter votre demande. Veuillez réessayer.";
      
      setMessages(prev => [...prev, { role: 'model', content: aiResponse }]);
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [...prev, { role: 'model', content: "Une erreur est survenue. Veuillez vérifier votre connexion ou réessayer plus tard." }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 100, scale: 0.9 }}
        animate={{ 
          opacity: 1, 
          y: 0, 
          scale: 1,
          height: isMinimized ? '64px' : '600px',
          width: isMinimized ? '300px' : '400px'
        }}
        exit={{ opacity: 0, y: 100, scale: 0.9 }}
        className="fixed bottom-6 right-6 bg-white rounded-[2rem] shadow-2xl border border-gray-100 z-[200] flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="bg-black p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3 text-white">
            <div className="w-8 h-8 bg-white/10 rounded-xl flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold">Assistant MAZE</p>
              {!isMinimized && <p className="text-[10px] text-white/50 uppercase tracking-widest">En ligne</p>}
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <button 
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-2 hover:bg-white/10 rounded-full text-white/70 transition-colors"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </button>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full text-white/70 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {!isMinimized && (
          <>
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/50">
              {messages.map((msg, idx) => (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ type: "spring", damping: 20, stiffness: 300 }}
                  key={idx}
                  className={cn(
                    "flex items-start space-x-3 max-w-[85%]",
                    msg.role === 'user' ? "ml-auto flex-row-reverse space-x-reverse" : ""
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0",
                    msg.role === 'user' ? "bg-black" : "bg-gray-200"
                  )}>
                    {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-gray-600" />}
                  </div>
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed shadow-sm",
                    msg.role === 'user' 
                      ? "bg-black text-white rounded-tr-none" 
                      : "bg-white text-gray-800 rounded-tl-none border border-gray-100"
                  )}>
                    {msg.content}
                  </div>
                </motion.div>
              ))}
              {isLoading && (
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-gray-200 rounded-xl flex items-center justify-center">
                    <Bot className="w-4 h-4 text-gray-600" />
                  </div>
                  <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-gray-100 shadow-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <form onSubmit={handleSend} className="p-4 bg-white border-t border-gray-100">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Posez votre question..."
                  className="w-full bg-gray-50 border-2 border-transparent rounded-2xl py-3 pl-4 pr-12 focus:border-black/5 focus:bg-white transition-all outline-none text-sm"
                />
                <button
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="absolute right-2 p-2 bg-black text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-800 transition-all"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[10px] text-center text-gray-400 mt-3">
                L'IA peut faire des erreurs. Vérifiez les informations importantes.
              </p>
            </form>
          </>
        )}
      </motion.div>
    </AnimatePresence>
  );
};

// Helper function for class names (copied from App.tsx or imported)
function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
