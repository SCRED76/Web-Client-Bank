import { Credentials } from './types';

export const USER_CREDENTIALS: Credentials = {
  "Eliott": "Elio_Maze!26",
  "Emilien": "Emi_Secure#99",
  "Nathan L": "NatL_Bank$20",
  "Leo": "Jv_Secure!2026#Px",
  "Nathan B": "NatB_Vault*88",
  "Antoine": "Anto_Safe@44"
};

export const SPREADSHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1ohACDnzUcX9Ga0IkN2zYlc0BgRx4imLg9TYeAYm-gFs/export?format=csv&gid=95103772&range=B27:L38";
