export interface Transaction {
  date: string;
  description: string;
  amount: string;
  type: 'up' | 'down';
}

export interface InvestmentDetail {
  label: string;
  amount: string;
}

export interface UserAccount {
  name: string;
  solde: string;
  livretA: string;
  investissements: string;
  compteEntreprise: string | null;
  performance: string | null;
  investBreakdown: InvestmentDetail[];
  transactions: Transaction[];
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  date: string;
  type: 'added' | 'removed' | 'update';
  isRead: boolean;
}

export interface Credentials {
  [username: string]: string;
}
